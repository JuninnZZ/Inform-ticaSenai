#include <stdio.h>

int main () {
    
    int num1 = 5, num2 = 4, soma;
    soma = num1 + num2;
    printf ("A soma das duas variaveis misteriosas eh: %i",soma);

    return 0;
}