#include <stdio.h>

int main () {
    
    int num1 = 0, num2 = 11, num3 = 1;
    
    for(num1 = 0; num1 <=10; num1++)
    {
        num2 -= num3;
    printf ("Desbloqueando o segredo em: %i \n",num2);
}
    printf ("Voce encontrou feitico de raio");
    return 0;
}
